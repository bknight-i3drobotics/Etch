# Etch
A simple drawing game for the Game Boy.  
For more information visit: github.com/GamesKnightStudios/Etch

# Controls
Arrows: Move and draw [Windows arrow keys]
A: Change colour [Windows S key]
B: Clear screen [Windows A key]